let one = document.querySelector("#one");
let two = document.querySelector("#two");
let three = document.querySelector("#three");
let four = document.querySelector("#four");
let five = document.querySelector("#five");
let six = document.querySelector("#six");
let seven = document.querySelector("#seven");
let eight = document.querySelector("#eight");
let nine = document.querySelector("#nine");

let i = 0;

let zeroooo = document.querySelector("#zeroooo");
let crossss = document.querySelector("#crossss");

let zero_score = 0;
let cross_score = 0;

let winner = [
  [1, 2, 3],
  [4, 5, 6],
  [7, 8, 9],
  [1, 4, 7],
  [2, 5, 8],
  [3, 6, 9],
  [1, 5, 9],
  [3, 5, 7],
];

let zero = [];
let cross = [];

function checkwinner(arr) {
  if (arr.length < 3) return false;

  for (let i = 0; i < winner.length; i++) {
    let q = 0;
    for (let j = 0; j < winner[i].length; j++) {
      let found = false;
      for (let k = 0; k < arr.length; k++) {
        if (winner[i][j] === arr[k]) {
          found = true;
          break; // No need to continue searching
        }
      }
      if (!found) {
        q = 1;
        break; // No need to check the rest of the row
      }
    }
    if (q === 0) return true; // All elements of the row are present
  }
  return false; // No winning combination found
}

function converter(arr) {
  if (arr[arr.length - 1] === "one") arr[arr.length - 1] = 1;
  if (arr[arr.length - 1] === "two") arr[arr.length - 1] = 2;
  if (arr[arr.length - 1] === "three") arr[arr.length - 1] = 3;
  if (arr[arr.length - 1] === "four") arr[arr.length - 1] = 4;
  if (arr[arr.length - 1] === "five") arr[arr.length - 1] = 5;
  if (arr[arr.length - 1] === "six") arr[arr.length - 1] = 6;
  if (arr[arr.length - 1] === "seven") arr[arr.length - 1] = 7;
  if (arr[arr.length - 1] === "eight") arr[arr.length - 1] = 8;
  if (arr[arr.length - 1] === "nine") arr[arr.length - 1] = 9;
  console.log(arr);
  if (checkwinner(arr) == true) return true;
  return false;
}

function renderBoard() {
  let elem = [one, two, three, four, five, six, seven, eight, nine];

  for (let e of elem) {
    // Check if the element has any child nodes
    if (e.childNodes.length > 0) {
      // Remove all child nodes
      while (e.firstChild) {
        e.removeChild(e.firstChild);
      }
    }
  }

  // Remove event listeners from all elements

    for (let e of elem) {
      e.addEventListener("click", clicked);
    }

    // Reset game state variables
    zero = [];
    cross = [];
    i = 0;
    let res = document.querySelector(".size")
    res.innerHTML = "Tic Tac Toe";
    zeroooo.innerHTML = zero_score;
    crossss.innerHTML = cross_score;
}

function clicked() {
    let res = document.querySelector(".size");
    let img = document.createElement("img");

  img.style.height = "8vw";
  img.style.width = "8vw";
  this.append(img);
  i++;
  this.removeEventListener("click", clicked);

  if (i % 2 == 0) {
    img.src = "zero.png";
    zero.push(this.id);
    if(zero.length == 4&&cross.length == 5){
        res.innerHTML = "DRAW";
        setTimeout(function () {
            renderBoard();
          }, 2000); // Delay before rendering board again (adjust as needed)
    }
    if (converter(zero) == true) {
      res.innerHTML = "zero won";
      one.removeEventListener("click", clicked);
      two.removeEventListener("click", clicked);
      three.removeEventListener("click", clicked);
      four.removeEventListener("click", clicked);
      five.removeEventListener("click", clicked);
      six.removeEventListener("click", clicked);
      seven.removeEventListener("click", clicked);
      eight.removeEventListener("click", clicked);
      nine.removeEventListener("click", clicked);
      zero_score ++;
      setTimeout(function () {
        renderBoard();
      }, 1000); // Delay before rendering board again (adjust as needed)
    }
  } else {
    img.src = "cross.png";
    cross.push(this.id);
    if(zero.length == 4&&cross.length == 5){

        res.innerHTML = "DRAW";


        setTimeout(function () {
            renderBoard();
          }, 2000); // Delay before rendering board again (adjust as needed)


    }


    if (converter(cross) == true) {


      res.innerHTML = "cross won";


      one.removeEventListener("click", clicked);
      two.removeEventListener("click", clicked);
      three.removeEventListener("click", clicked);
      four.removeEventListener("click", clicked);
      five.removeEventListener("click", clicked);
      six.removeEventListener("click", clicked);
      seven.removeEventListener("click", clicked);
      eight.removeEventListener("click", clicked);
      nine.removeEventListener("click", clicked);

      cross_score++;
      setTimeout(function () {
        renderBoard();
      }, 2000); // Delay before rendering board again (adjust as needed)

    }
  }
}





one.addEventListener("click", clicked);
two.addEventListener("click", clicked);
three.addEventListener("click", clicked);
four.addEventListener("click", clicked);
five.addEventListener("click", clicked);
six.addEventListener("click", clicked);
seven.addEventListener("click", clicked);
eight.addEventListener("click", clicked);
nine.addEventListener("click", clicked);